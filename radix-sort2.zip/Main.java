import java.util.*;
class Main {  
 static int Max(int a[],int n) {  
   int max = a[0];  
   for(int i = 1; i<n; i++) 
   max=Math.max(max,a[i]);
   return max; 
}  
static void cSrt(int a[],int n,int p)   
{  
 int b[]= new int[n+1];  
 int c[] = new int[10];  
  for (int i=0;i<n;i++)  
    c[(a[i]/p)%10]++;  
  for (int i=1;i<10;i++)  
    c[i]+=c[i-1];  
  for (int i=n-1;i>=0;i--) {  
    b[c[(a[i]/p)%10]-1]=a[i];  
    c[(a[i]/p)%10]--;  
  }  
  for (int i=0;i<n;i++)  
    a[i]=b[i];  
}  
static void radixsort(int a[],int n) {  
  int m=Max(a,n);  
  for (int i=1;m/i>0;i*=10)  
    cSrt(a,n,i);  
}  
static void dis(int a[],int n) {  
  for (int i=0;i<n;i++)   
    System.out.print(a[i]+" ");  
}  
  public static void main(String args[]) {
      Scanner s=new Scanner(System.in);
      int n=s.nextInt();
  int a[]=new int[n];  
  for(int i=0;i<n;i++)
  a[i]=s.nextInt();
  dis(a,n);  
  radixsort(a, n);  
  System.out.print("\nAfter sort the array elements\n");  
  dis(a,n);  
}  
  }  