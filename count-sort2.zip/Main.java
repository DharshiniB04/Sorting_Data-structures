import java.util.*;
class Main {  
static int Max(int[] a,int n) {  
  int max = a[0];  
  for(int i=1;i<n;i++)  
    max=Math.max(max,a[i]); 
  return max;  
}  
static void countSort(int[] a,int n)   
{  
   int b[]= new int[n+1];  
   int m=Max(a,n);  
   int c[]=new int[m+1];  
  for (int i=0;i<n;i++)  
    c[a[i]]++;  
   for(int i=1;i<=m;i++)   
      c[i]+=c[i-1];  
  for (int i=n-1;i>=0;i--) {  
    b[c[a[i]]-1]=a[i];  
    c[a[i]]--;  
}  
   for(int i=0;i<n;i++)   
      a[i]=b[i];  
}  
static void dis(int a[],int n)  
{ 
    for(int i=0;i<n;i++)  
        System.out.print(a[i]+" ");  
}  
public static void main(String args[])  
{  
    Scanner s=new Scanner(System.in);
      int n=s.nextInt();
  int a[]=new int[n];  
  for(int i=0;i<n;i++)
  a[i]=s.nextInt();
    dis(a,n);  
    countSort(a,n);  
    System.out.println("\nAfter sorting array elements");  
    dis(a,n);  
}  
}  