import java.util.*;
public class Main
{  
static int Max(int a[],int n)   
{  
    int max = a[0];  
    for (int i = 1; i < n; i++)  
    max=Math.max(max,a[i]);  
    return max;  
}  
static void bktsort(int a[],int n)   
{  
    int m = Max(a,n);   
    int b[] = new int[m+1];   
    for (int i=0;i<=m;i++)  
    {  
        b[i]=0;  
    }  
    for (int i=0;i<n;i++)  
    {  
        b[a[i]]++;  
    }  
    for (int i=0,j=0;i<=m;i++)  
    {  
        while(b[i]>0)  
        {  
            a[j++]=i;  
            b[i]--;  
        }  
    }  
}  
static void dis(int a[],int n)   
{ 
    for (int i=0;i<n;i++)  
    System.out.print(a[i] + " ");  
}  
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        int n=s.nextInt();
    int a[]=new int[n];  
    for(int i=0;i<n;i++)
    a[i]=s.nextInt();
    dis(a,n);  
    bktsort(a,n);  
    System.out.print("\nAfter sorting array elements\n");  
    dis(a,n);  
    }
}